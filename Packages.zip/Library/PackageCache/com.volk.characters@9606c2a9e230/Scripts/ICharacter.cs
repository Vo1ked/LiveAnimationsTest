﻿namespace VolkCharacters
{
    public interface ICharacter
    {
        
    }
}