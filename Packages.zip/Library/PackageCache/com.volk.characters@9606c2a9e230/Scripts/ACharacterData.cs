﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VolkCharacters.Abilities;

namespace VolkCharacters
{
    [CreateAssetMenu(fileName = "Character", menuName = "Volk/Characters/Character", order = 0)]
    public class ACharacterData : ScriptableObject
    {
       [field:SerializeField] public string Name { get; protected set; } = "ACharacter";
       [field:SerializeField] public int Id { get; protected set; } = -1;
       [field:SerializeField] public bool Available { get; protected set; } = true;
       [field:SerializeField] public Sprite Sprite { get; protected set; }
       [field:SerializeField] public AAbility[] Abilities { get; protected set; }

       public void UseAbilities(UsePlace place,ICharacter character, List<AAbility> abilities = null)
       {
           abilities = abilities == null 
               ? Abilities.Where(x=>x.UsePlace == place).ToList() 
               : abilities.Where(x => x.UsePlace == place).ToList();

           if (abilities.Count > 0)
           {
               abilities.ForEach(x => x.Use(character));
           }
       }
    }
}