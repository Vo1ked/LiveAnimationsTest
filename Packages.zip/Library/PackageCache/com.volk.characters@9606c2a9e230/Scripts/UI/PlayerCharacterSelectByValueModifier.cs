﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;
using VolkCharacters.Save;
using VolkCharacters.Signals;
using VolkCore.UI;
using Zenject;

namespace VolkCharacters
{
    public class PlayerCharacterSelectByValueModifier : BasePopUp
    {
        [SerializeField] private ValueModifierPanel _valueModifierPanel;
        [SerializeField] private Image _characterImage;
        [SerializeField] private TMP_Text _characterName;
        [SerializeField] private Button _selectButton;

        [Inject] private ICharactersData<ACharacterData> _charactersData;
        [Inject] private SignalBus _signalBus;
        [Inject(Id = "CharacterSelect")] private IUiLock _uiLock;

        private void Awake()
        {
            _characterImage.sprite = _charactersData.SelectedCharacter.Sprite;

            _valueModifierPanel.OnValueIncrease += ShowNextCharacter;
            _valueModifierPanel.OnValueDecrease += ShowPreviousCharacter;

            _selectButton.onClick.AddListener(CharacterSelected);
        }

        private void CharacterSelected()
        {
            _charactersData.SaveCharacter();
            _signalBus.Fire<CharacterSelectedSignal>();
        }

        private void ShowNextCharacter()
        {
            var character = _charactersData.NextCharacter();
            if (_characterName != null)
            {
                _characterName.text = character.Name;
            }

            if (_selectButton != null)
            {
                _selectButton.interactable = character.Available;
            }

            if (character.Available)
            {
                _uiLock.Lock();
            }
            else
            {
                _uiLock.Unlock();
            }
            _characterImage.sprite = character.Sprite;
        }

        private void ShowPreviousCharacter()
        {
            var character = _charactersData.PreviousCharacter();
            if (_characterName != null)
            {
                _characterName.text = character.Name;
            }

            if (_selectButton != null)
            {
                _selectButton.interactable = character.Available;
            }

            if (character.Available)
            {
                _uiLock.Lock();
            }
            else
            {
                _uiLock.Unlock();
            }
            _characterImage.sprite = character.Sprite;
        }
    }
}