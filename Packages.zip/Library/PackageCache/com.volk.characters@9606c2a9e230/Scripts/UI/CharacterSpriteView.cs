﻿using System;
using UnityEngine;

namespace VolkCharacters
{
    [Serializable]
    public class CharacterSpriteView
    {
        [field:SerializeField] public int Id { get; private set; }
        [field:SerializeField] public Sprite Sprite { get; private set; }
    }
}