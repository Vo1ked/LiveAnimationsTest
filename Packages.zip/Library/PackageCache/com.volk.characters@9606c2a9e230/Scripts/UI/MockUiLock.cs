﻿namespace VolkCharacters
{
    public class MockUiLock : IUiLock
    {
        public void Lock(){}
        public void Unlock(){}
    }
}