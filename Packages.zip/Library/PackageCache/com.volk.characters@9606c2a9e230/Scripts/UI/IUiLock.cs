﻿
namespace VolkCharacters
{
    public interface IUiLock
    {
        public void Lock();
        public void Unlock();
    }
}