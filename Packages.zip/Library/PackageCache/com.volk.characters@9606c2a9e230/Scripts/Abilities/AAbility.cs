﻿using System;
using UnityEngine;

namespace VolkCharacters.Abilities
{
    [Serializable]
    public abstract class AAbility : ScriptableObject
    {
        [field: SerializeField] public virtual string Name { get; protected set; } = "AAbility";
        [field: SerializeField] public virtual UsePlace UsePlace { get; protected set; } = UsePlace.None;

        public virtual void Use(ICharacter character) { }
    }

    public enum UsePlace
    {
        None,
        TakeDamage,
        MakeDamage,
        TakeHeal,
        Touch,
        Spawn,
        Die
    }
}