﻿namespace VolkCharacters.Signals
{

    public struct CharacterSelectedSignal {}

    public struct FromCharacterSignal<TEvent>
    {
        public readonly ACharacterData CharacterData;

        public FromCharacterSignal(ACharacterData characterData)
        {
            CharacterData = characterData;
        }
    }

    public struct OnHit { }
    public struct OnHeal { }
    public struct OnSpawn { }
    public struct OnDie { }
}