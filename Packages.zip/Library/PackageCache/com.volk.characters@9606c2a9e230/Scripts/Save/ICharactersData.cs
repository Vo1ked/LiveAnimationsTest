﻿namespace VolkCharacters.Save
{
    public interface ICharactersData<out T> where T : ACharacterData
    {
        T SelectedCharacter { get; }
        T NextCharacter();
        T PreviousCharacter();
        T GetCharacterById(int id);
        void SaveCharacter();
    }
}