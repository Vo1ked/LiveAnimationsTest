﻿using System;
using System.Linq;
using ModestTree;
using UnityEngine;
using VolkCore.Save;
using Zenject;

namespace VolkCharacters.Save
{
    public class ACharactersData<TCharacter> : ScriptableObject, ICharactersData<TCharacter>,IDisposable
        where TCharacter : ACharacterData
    {
        protected virtual string CharacterType { get;} = "ACharacter";
        [field: SerializeField] public TCharacter[] Characters { get; private set; }

        private TCharacter _selectedCharacter;

        public TCharacter SelectedCharacter
        {
            get
            {
                if (_selectedCharacter != null)
                    return _selectedCharacter;

                _selectedCharacter = LoadCharacter();
                return _selectedCharacter;
            }
        }

        private string _userId;
        private int _selectedCharacterIndex;

        private TCharacter LoadCharacter()
        {
            _userId = PlayerPrefs.GetString("UserId");
            var encryptedCharacter = PlayerPrefs.GetString(CharacterType);
            TCharacter character;
            if (string.IsNullOrEmpty(_userId) || string.IsNullOrEmpty(encryptedCharacter))
            {
                character = Characters.First(x => x.Id == NewUser());
                _selectedCharacterIndex = Characters.IndexOf(character);
                return character;
            }

            var characterId = DataDecryptor.DecryptString(encryptedCharacter, _userId);
            character = Characters.First(x => x.Id == int.Parse(characterId));
            _selectedCharacterIndex = Characters.IndexOf(character);
            return character;
        }
        
        public TCharacter NextCharacter()
        {
            _selectedCharacterIndex = (_selectedCharacterIndex + 1) % Characters.Length;
            _selectedCharacter = Characters[_selectedCharacterIndex];
            return _selectedCharacter;
        }

        public TCharacter PreviousCharacter()
        {
            _selectedCharacterIndex = (_selectedCharacterIndex - 1 + Characters.Length) % Characters.Length;
            _selectedCharacter = Characters[_selectedCharacterIndex];
            return _selectedCharacter;
        }

        public TCharacter GetCharacterById(int id)
        {
            var character = Characters.FirstOrDefault(x => x.Id == id);
            if (character == null)
            {
                Debug.LogError($"Character with id {id} not found");
                return _selectedCharacter;
            }

            _selectedCharacter = character;
            _selectedCharacterIndex = Characters.IndexOf(character);
            return character;
        }

        public void SaveCharacter()
        {
            var characterData = DataEncryptor.EncryptString(_selectedCharacter.Id.ToString(), _userId);
            PlayerPrefs.SetString(CharacterType, characterData);
        }

        private int NewUser()
        {
            _userId = Guid.NewGuid().ToString();
            PlayerPrefs.SetString("UserId", _userId);
            PlayerPrefs.Save();
            return 0;
        }

        public void Dispose()
        {
            SaveCharacter();
        }
    }
}