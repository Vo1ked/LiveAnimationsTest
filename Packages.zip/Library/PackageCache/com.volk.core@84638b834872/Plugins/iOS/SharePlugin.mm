#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

extern "C" void _ShareText(const char* message)
{
    UIViewController *viewController = [UIApplication sharedApplication].keyWindow.rootViewController;

    NSString *text = [NSString stringWithUTF8String:message];
    NSArray *objectsToShare = @[text];

    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:objectsToShare applicationActivities:nil];

    [viewController presentViewController:activityVC animated:YES completion:nil];
}
