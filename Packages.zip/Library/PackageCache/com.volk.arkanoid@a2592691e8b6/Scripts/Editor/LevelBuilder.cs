﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VolkArkanoid.Save;
using VolkArkanoid.Signals;
using Zenject;

namespace VolkArkanoid.Scripts.Editor
{
    public class LevelBuilder : MonoBehaviour
    {
        [SerializeField] private Transform Container;
        [SerializeField] private int Level = 0;
        [SerializeField] private ManualCreatedLevels levelFactory;
        [SerializeField] private Block _blockPrefab;
        
        [Inject] private SignalBus _signalBus;
        [Inject] private DiContainer _container;

        private int _currentBlockId;
        private bool _editor = true;
        public void Awake()
        {
            _signalBus.Subscribe<LoadLevelSignal>(LoadLevelBySignal);
        }
#if UNITY_EDITOR
        [ContextMenu("Save Level")]
        public void SaveLevel()
        {
            var level = new LevelData();
            var blocks = new List<BlockData>();
            level.Level = Level;
            _currentBlockId = 0;
            foreach (Transform blockTransform in Container)
            {
                var block = blockTransform.GetComponent<Block>();
                if (block == null)
                  continue;
                var blockData = new BlockData(blockTransform.position, block.BlockData.Destroyable
                    ,_currentBlockId++,block.BlockData.Abilities);
                blocks.Add(blockData);
            }
            level.Blocks = blocks.ToArray();
            levelFactory.AddLevel(level);
            UnityEditor.EditorUtility.SetDirty(levelFactory);
            UnityEditor.AssetDatabase.SaveAssets();
        }
#endif
        [ContextMenu("Load Level")]
        public void LoadLevel()
        {
            if (levelFactory == null)
                return;
            var level = levelFactory.GetLevel(Level);
            if (levelFactory.GetLevel(Level) == null)
                return;
            if (Container.childCount > 0)
            {
                foreach (Transform child in Container.Cast<Transform>().ToArray())
                {
                    DestroyImmediate(child.gameObject);
                }
            }

            foreach (var block in level.Blocks)
            {
                var blockInstance = Instantiate(_blockPrefab, Container);
                blockInstance.name = "Block_" + block.BlockId;
                blockInstance.transform.position = block.StartPosition;
                if (_editor)
                {
                    blockInstance.EditorInitialize(block);
                }
                else
                {
                    blockInstance.Initialize(block);
                    _container.Inject(blockInstance);
                }
            }
        }

        private void LoadLevelBySignal(LoadLevelSignal signal)
        {
            Level = signal.Level;
            _editor = false;
            LoadLevel();
        }
        
    }
}