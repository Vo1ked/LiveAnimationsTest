﻿using System.Linq;
using UnityEngine;
using VolkArkanoid.Abilities;
using VolkArkanoid.Save;
using VolkArkanoid.Signals;
using VolkCharacters;
using VolkCharacters.Abilities;
using Zenject;

namespace VolkArkanoid
{
    public class Block : MonoBehaviour, IHittable, ICharacter
    {
        [field:SerializeField] public SpriteRenderer Renderer { get;private set; }

        [Inject] private SignalBus _signalBus;

        public BlockData BlockData;
        private int _currentHealth = 1;
        
        public void Initialize(BlockData blockData)
        {
            BlockData = blockData;
            UseAbilities(UsePlace.Spawn);
            SetColorByMaxHealth(_currentHealth);
        }

        public void EditorInitialize(BlockData blockData)
        {
            BlockData = blockData;
            ShowHeals();
            transform.position = blockData.StartPosition;
        }
        
        public void Hit(Ball ball)
        {
            UseAbilities(UsePlace.TakeDamage);
            if (!BlockData.Destroyable)
                return;
            RemoveHealth(ball.Damage);
            if (_currentHealth <= 0)
                return;
            SetColorByMaxHealth(_currentHealth);
            ball.Reflect();
        }

        public void AddHealth(int amount)
        {
           _currentHealth = amount;
        }
        [ContextMenu("ShowHeals")]
        public void ShowHeals()
        {
            var heals = BlockData.Abilities.FirstOrDefault(x => x is MoreHeals);
            if (heals is MoreHeals moreHeals)
            {
                SetColorByMaxHealth(moreHeals.AdditionalHealsCount);
            }
            else
            {
                SetColorByMaxHealth(1);
            }
        }

        private void RemoveHealth(int amount)
        {
            _currentHealth -= amount;
            if (_currentHealth <= 0 )
            {
                Die();
            }
        }
        
        private void UseAbilities(UsePlace place)
        {
            var abilities = BlockData.Abilities.Where(x => x.UsePlace == place).ToList();
            if (abilities.Count > 0)
            {
                abilities.ForEach(x => x.Use(this));
            }
        }
        
        private void SetColorByMaxHealth(int maxHealth)
        {
            Renderer.color = GetColorForMaxHealth(maxHealth);
        }

        private Color GetColorForMaxHealth(int health)
        {
            return health switch
            {
                1=>new Color(0.8f, 0.8f, 0.8f),
                2=>new Color(0.3f, 0.9f, 0.3f),
                3=>Color.yellow,
                4=>new Color(1f, 0.5f, 0f),
                _=>Color.red
            };
        }

        private void Die()
        {
            UseAbilities(UsePlace.Die);
            if (_currentHealth > 0)
                return;
            
            _signalBus.Fire(new BlockDestroyedSignal(BlockData.BlockId));
            Destroy(gameObject);
        }
    }
}