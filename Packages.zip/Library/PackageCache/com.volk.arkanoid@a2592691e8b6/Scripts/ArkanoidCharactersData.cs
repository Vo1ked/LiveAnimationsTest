﻿using UnityEngine;
using VolkCharacters.Save;

namespace VolkArkanoid
{
    [CreateAssetMenu(fileName = "ArkanoidCharacters", menuName = "Volk/Arkanoid/CharactersData", order = 0)]
    public class ArkanoidCharactersData : ACharactersData<ArkanoidPlayer>
    {
        protected override string CharacterType => "Arkanoid";
    }
}