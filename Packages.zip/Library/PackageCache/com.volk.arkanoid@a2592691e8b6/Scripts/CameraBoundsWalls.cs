﻿using Packages.VolkArkanoid.Scripts;
using UnityEngine;
using Zenject;

namespace VolkArkanoid
{
    public class CameraBoundsWalls : MonoBehaviour
    {
        [SerializeField] private float _targetWidth = 10f;
        [SerializeField] private float _wallThickness = 2f;
        [SerializeField] private float _topWallOffset = 10f;
        [SerializeField] private float wallDepth = 1f;
        [SerializeField] private GameObject _wallPrefab; 
        [SerializeField] private Camera _camera;

        [Inject] private DiContainer _container;
        private void Start()
        {
            AdjustCameraSize();
            CreateWalls();
        }

        private void AdjustCameraSize()
        {
            float screenAspect = (float)Screen.width / Screen.height;
            float targetHeight = _targetWidth / screenAspect;
            _camera.orthographicSize = targetHeight / 2f;
        }

        private void CreateWalls()
        {
            Vector2 camSize = new Vector2(_camera.orthographicSize * _camera.aspect * 2f, _camera.orthographicSize * 2f);
            
            var wall = Instantiate(_wallPrefab, new Vector2(-camSize.x / 2f - _wallThickness / 2f, 0)
                , Quaternion.identity, transform);
            wall.transform.localScale = new Vector3(_wallThickness, camSize.y, wallDepth);
            wall.name = "LeftWall";
            _container.InstantiateComponent<Wall>(wall);
            
            wall = Instantiate(_wallPrefab, new Vector2(camSize.x / 2f + _wallThickness / 2f, 0)
                , Quaternion.identity, transform);
            wall.transform.localScale = new Vector3(_wallThickness, camSize.y);
            wall.name = "RightWall";
            _container.InstantiateComponent<Wall>(wall);
            
            float overlap = -0.2f;

            wall = Instantiate(_wallPrefab,
                new Vector2(-camSize.x / 2f - _wallThickness / 2f - _wallThickness - overlap, 0),
                Quaternion.identity, transform);
            wall.transform.localScale = new Vector3(_wallThickness, camSize.y, wallDepth);
            wall.name = "ExtraLeftWall";
            _container.InstantiateComponent<Wall>(wall);

            wall = Instantiate(_wallPrefab, 
                new Vector2(camSize.x / 2f + _wallThickness / 2f + _wallThickness + overlap, 0),
                Quaternion.identity, transform);
            wall.transform.localScale = new Vector3(_wallThickness, camSize.y);
            wall.name = "ExtraRightWall";
            _container.InstantiateComponent<Wall>(wall);
            
            wall = Instantiate(_wallPrefab, new Vector2(0, camSize.y / 2f + _wallThickness - _topWallOffset / 2f)
                , Quaternion.identity, transform);
            wall.transform.localScale = new Vector3(camSize.x, _wallThickness);
            wall.name = "TopWall";
            _container.InstantiateComponent<Wall>(wall);
            
            wall = Instantiate(_wallPrefab, new Vector2(0, -camSize.y / 2f - _wallThickness / 2f)
                , Quaternion.identity, transform);
            wall.transform.localScale = new Vector3(camSize.x, _wallThickness);
            wall.name = "Floor";
            _container.InstantiateComponent<Floor>(wall);

        }

    }

}