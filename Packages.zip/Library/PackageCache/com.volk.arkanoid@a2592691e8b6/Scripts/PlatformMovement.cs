﻿using System;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using VolkArkanoid.Signals;
using VolkCore.Collections;
using VolkInput;
using Zenject;

namespace VolkArkanoid
{
    public class PlatformMovement : MonoBehaviour, IPausable
    {
        [Inject] private SignalBus _signalBus;
        [Inject(Id = "GameCamera")] private Camera _camera;
        [Inject] private IVolkInput _volkInput;

        private bool _isPressed;
        private Vector2 _currentTarget;
        private CancellationTokenSource _cts;
        public bool InPause;

        private void OnEnable()
        {
            _volkInput.OnPressStart += OnTouchStarted;
            _volkInput.OnPressContinue += OnTouchMoved;
            _volkInput.OnPressEnd += OnTouchCanceled;
        }

        private void OnDisable()
        {
            _volkInput.OnPressStart -= OnTouchStarted;
            _volkInput.OnPressContinue -= OnTouchMoved;
            _volkInput.OnPressEnd -= OnTouchCanceled;

            _cts?.Cancel();
            _isPressed = false;
        }

        private void OnTouchStarted()
        {
            if (InPause || _cts != null)
                return;

            _isPressed = true;
            _cts = new CancellationTokenSource();
            _ = MovePlatformAsync(_cts.Token);
        }

        private void OnTouchMoved(Vector2 position)
        {
            _currentTarget = position;
        }

        private void OnTouchCanceled()
        {
            _isPressed = false;
            _cts?.Cancel();
            _cts?.Dispose();
            _cts = null;
            _signalBus.Fire<PlatformReleasedSignal>();
        }

        private async Task MovePlatformAsync(CancellationToken token)
        {
            try
            {
                while (_isPressed && !token.IsCancellationRequested)
                {
                    Vector3 worldPosition = _camera.ScreenToWorldPoint(new Vector3(_currentTarget.x, _currentTarget.y,
                        -_camera.transform.position.z));
                    transform.position = new Vector2(worldPosition.x, transform.position.y);
                    await Awaitable.NextFrameAsync(token);
                }
            }
            catch (OperationCanceledException) { }
        }

        public void OnPause()
        {
            InPause = true;
            OnTouchCanceled();
        }

        public void OnResume()
        {
            InPause = false;
        }
    }
}
