using UnityEngine;
using VolkArkanoid.Signals;
using VolkCharacters.Signals;
using VolkCore.Collections;
using VolkCore.Game;
using VolkCore.UI;
using Zenject;

namespace VolkArkanoid
{
    public class ArkanoidGameInstaller : ASceneInstaller
    {
        [SerializeField] private TopPanel _topPanel;
        [SerializeField] private Camera _gameCamera;
        [SerializeField] private Platform _platform;
        [SerializeField] private Ball _ball;
        
        public override void InstallBindings()
        {
            if (!CheckAndLogDependencies())
                return;
            
            Container.Bind<TopPanel>().FromInstance(_topPanel).AsSingle();
            Container.Bind<Camera>().WithId("GameCamera").FromInstance(_gameCamera).AsSingle();
            Container.Bind<Platform>().FromInstance(_platform).AsSingle();
            Container.Bind<Ball>().FromInstance(_ball).AsSingle();
            Container.Bind<PauseManager>().ToSelf().AsSingle();
            
            Container.DeclareSignal<LoadLevelSignal>();
            Container.DeclareSignal<BlockDestroyedSignal>();
            Container.DeclareSignal<FromCharacterSignal<OnSpawn>>();
            Container.DeclareSignal<FromCharacterSignal<OnHeal>>();
            Container.DeclareSignal<FromCharacterSignal<OnDie>>();
            Container.DeclareSignal<FromCharacterSignal<OnHit>>();
            Container.DeclareSignal<PlatformReleasedSignal>().OptionalSubscriber();
            Container.DeclareSignal<FloorRichSignal>();
            Container.DeclareSignal<GameLoseSignal>();
            Container.DeclareSignal<GameWinSignal>();
        }
    }
}