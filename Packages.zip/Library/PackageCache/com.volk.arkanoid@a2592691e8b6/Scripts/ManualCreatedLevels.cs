﻿using System.Collections.Generic;
using UnityEngine;
using VolkArkanoid.Save;
using VolkCore.Game;

namespace VolkArkanoid
{
    [CreateAssetMenu(fileName = "Levels", menuName = "Volk/Arkanoid/Levels", order = 1)]
    public class ManualCreatedLevels : ALevelFactory<LevelData>
    {
        [field:SerializeField] private List<LevelData> _levels;
        public override LevelData[] GenerateLevels()
        {
            return _levels.ToArray();
        }
        public void AddLevel(LevelData level)
        {
            var existingIndex = _levels.FindIndex(l => l.Level == level.Level);
            if (existingIndex >= 0)
            {
                _levels[existingIndex] = level;
            }
            else
            {
                _levels.Add(level);
            }
        }

        public LevelData GetLevel(int level)
        {
            var existingIndex = _levels.FindIndex(l => l.Level == level);
            return existingIndex >= 0 ? _levels[level] : null;
        }
    }
}