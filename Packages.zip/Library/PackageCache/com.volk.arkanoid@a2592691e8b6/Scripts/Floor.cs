﻿using UnityEngine;
using VolkArkanoid;
using VolkArkanoid.Signals;
using Zenject;

namespace Packages.VolkArkanoid.Scripts
{
    public class Floor : MonoBehaviour, IHittable
    {
        [Inject] private SignalBus _signalBus;
        public void Hit(Ball ball)
        {
            _signalBus.Fire<FloorRichSignal>();
            ball.Speed = 0;
        }
    }
}