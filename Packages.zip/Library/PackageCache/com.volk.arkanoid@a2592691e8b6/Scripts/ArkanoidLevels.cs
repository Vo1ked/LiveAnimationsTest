﻿using VolkArkanoid.Save;
using VolkCore.Save;

namespace Packages.VolkArkanoid.Scripts
{
    public class ArkanoidLevels : AGameLevels<LevelData>
    {
        protected override string GameName => "Arkanoid";

        protected override void LoadLevels()
        {
            Levels = LevelFactory.GenerateLevels();
        }
    }
}