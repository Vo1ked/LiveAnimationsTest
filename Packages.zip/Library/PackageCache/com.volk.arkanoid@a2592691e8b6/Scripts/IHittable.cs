﻿namespace VolkArkanoid
{
    public interface IHittable
    {
        public void Hit(Ball ball);
    }
}