﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using VolkArkanoid.Abilities;
using VolkArkanoid.Save;
using VolkArkanoid.Signals;
using VolkCore.Collections;
using VolkCore.Save;
using VolkCore.UI;
using Zenject;

namespace VolkArkanoid
{
    public class ArkanoidGame : MonoBehaviour, IPausable
    {
        [Inject] private ArkanoidCharactersData _arkanoidCharacters;
        [Inject] private Platform _platform;
        [Inject] private Ball _ball;
        [Inject] private AGameLevels<LevelData> _levels;
        [Inject] private SignalBus _signalBus;
        [Inject] private DiContainer _container;
        [Inject] private TopPanel _topPanel;
        
        private Dictionary<int,BlockData> _blocks = new Dictionary<int,BlockData>();
        private int _currentHeals;
        private float _ballspeed;

        public void Awake()
        {
            _topPanel.OnClose(() => SceneManager.LoadScene(0));
        }

        private void Start()
        {
            var startMagnet = ScriptableObject.CreateInstance<StartMagnet>();
            var blocks = _levels.CurrentLevel.Blocks.Where((x)=>x.Destroyable);
            foreach (var block in blocks)
            {
                _blocks.Add(block.BlockId, block);
            }
            _currentHeals = _arkanoidCharacters.SelectedCharacter.StartHealth;
            _ballspeed = _arkanoidCharacters.SelectedCharacter.StartBallSpeed;
            _signalBus.Subscribe<BlockDestroyedSignal>(OnBlockDestroyed);
            _signalBus.Subscribe<FloorRichSignal>(OnFloorRich);
            _container.Inject(startMagnet);
            _platform.SessionAbilities.Add(startMagnet);
            _signalBus.Fire(new LoadLevelSignal(_levels.CurrentLevel.Level));
            _platform.Initialize(_arkanoidCharacters.SelectedCharacter);
        }

        private void OnFloorRich()
        {
            _currentHeals--;
            if (_currentHeals <= 0)
            {
                _signalBus.Fire<GameLoseSignal>();
                return;
            }
            
            //TODO add logic for replace ball to platform and re add start magnet
        }

        private void OnBlockDestroyed(BlockDestroyedSignal block)
        {
            _blocks.Remove(block.BlockId);
            if (_blocks.Count > 0)
                return;

            if (_levels.CurrentLevelId == _levels.MaxOppenedLevel)
            {
                _levels.IncrementLevel();
            }
            _signalBus.Fire<GameWinSignal>();
            _ball.Speed = 0;
        }


        public void OnPause()
        {
            _ball.Speed = 0;
        }

        public void OnResume()
        {
            _ball.Speed = _ballspeed;
        }
    }
}