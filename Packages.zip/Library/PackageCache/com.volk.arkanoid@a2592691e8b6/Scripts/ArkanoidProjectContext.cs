﻿using Packages.VolkArkanoid.Scripts;
using Save;
using UnityEngine;
using VolkArkanoid.Save;
using VolkCharacters;
using VolkCharacters.Save;
using VolkCore.Game;
using VolkCore.Save;
using Zenject;

namespace VolkArkanoid
{
    public class ArkanoidProjectContext : ASceneInstaller
    {
        [SerializeField] private ArkanoidCharactersData _playerCharactersData;
        [SerializeField] private ManualCreatedLevels _levels;

        public override void InstallBindings()
        {
            if (!CheckAndLogDependencies())
                return;
            
            Container.Bind<ALevelFactory<LevelData>>().FromInstance(_levels).AsSingle();
            Container.Bind(typeof(AGameLevels<LevelData>),typeof(IInitializable),typeof(ILevelProgress)).
                To<ArkanoidLevels>().FromNew().AsSingle();
            Container.Bind(typeof(ICharactersData<ACharacterData>),typeof(ArkanoidCharactersData))
                .To<ArkanoidCharactersData>().FromInstance(_playerCharactersData).AsSingle();
        }
    }
}