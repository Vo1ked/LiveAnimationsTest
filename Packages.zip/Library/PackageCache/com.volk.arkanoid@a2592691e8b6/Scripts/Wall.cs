﻿using UnityEngine;

namespace VolkArkanoid
{
    public class Wall : MonoBehaviour , IHittable
    {
        public void Hit(Ball ball)
        {
            ball.Reflect();
        }
    }
}