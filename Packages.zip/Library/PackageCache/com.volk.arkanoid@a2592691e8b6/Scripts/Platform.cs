﻿using System.Collections.Generic;
using UnityEngine;
using VolkCharacters;
using VolkCharacters.Abilities;
using VolkCharacters.Signals;
using VolkCore.Collections;
using Zenject;
using UsePlace = VolkCharacters.Abilities.UsePlace;

namespace VolkArkanoid
{
    public class Platform : MonoBehaviour , IHittable, ICharacter 
    {
        [SerializeField] private SpriteRenderer _sprite;
        [SerializeField] private BoxCollider2D _collider;

        [Inject] protected SignalBus SignalBus;
        
        private ArkanoidPlayer _arkanoidPlayer;
        public List<AAbility> SessionAbilities = new List<AAbility>();
        private int _currentHeals;
        public int LastTakenDamage;
        public int LastHeal;
        public void Initialize(ArkanoidPlayer arkanoidPlayer)
        {
            _arkanoidPlayer = arkanoidPlayer;
            _sprite.color = _arkanoidPlayer.PlatformColor;
            _sprite.size = new Vector2(_arkanoidPlayer.StartPlatformSize, _sprite.size.y);
            _collider.size = new Vector2(_arkanoidPlayer.StartPlatformSize, _sprite.size.y);
            Spawn();
        }

        private void AddSize(Vector2 size)
        {
            if (_sprite.size.x >= _arkanoidPlayer.MaxPlatformSize)
                return;
            _sprite.size += size;
            _collider.size += size;
        }
        
        public void Hit(Ball ball)
        {
            float hitX = ball.transform.position.x;
            float platformCenterX = transform.position.x;
            float halfWidth = _collider.size.x * 0.5f;

            float offset = hitX - platformCenterX;
            float normalizedOffset = Mathf.Clamp(offset / halfWidth, -1f, 1f);
            Vector2 newDirection = new Vector2(normalizedOffset, 1f).normalized;
            ball.Direction = newDirection;

            _arkanoidPlayer.UseAbilities(UsePlace.Touch, this);
        }
        
        
        private void Spawn()
        {
            _currentHeals = _arkanoidPlayer.StartHealth;

            _arkanoidPlayer.UseAbilities(UsePlace.Spawn,this);
            _arkanoidPlayer.UseAbilities(UsePlace.Spawn,this,SessionAbilities);

            SignalBus.Fire(new FromCharacterSignal<OnSpawn>(_arkanoidPlayer));
        }

        private void TakeHeal(int amount)
        {
            _arkanoidPlayer.UseAbilities(UsePlace.TakeHeal,this);
            _arkanoidPlayer.UseAbilities(UsePlace.TakeHeal,this,SessionAbilities);

            _currentHeals += LastHeal;
            SignalBus.Fire(new FromCharacterSignal<OnHeal>(_arkanoidPlayer));
        }

        private void TakeDamage(int amount)
        {
            _arkanoidPlayer.UseAbilities(UsePlace.TakeDamage,this);
            _arkanoidPlayer.UseAbilities(UsePlace.TakeDamage,this,SessionAbilities);
            _currentHeals -= LastTakenDamage;
            SignalBus.Fire(new FromCharacterSignal<OnHit>(_arkanoidPlayer));

            if (_currentHeals <= 0)
                Die();
        }

        private void Die()
        {
            _arkanoidPlayer.UseAbilities(UsePlace.Die,this);
            _arkanoidPlayer.UseAbilities(UsePlace.TakeDamage,this,SessionAbilities);
            if (_currentHeals <= 0)
            {
                SignalBus.Fire(new FromCharacterSignal<OnDie>(_arkanoidPlayer));
            }
        }


    }
}