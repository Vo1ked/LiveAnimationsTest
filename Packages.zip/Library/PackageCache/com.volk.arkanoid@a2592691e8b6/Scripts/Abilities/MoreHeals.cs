﻿using UnityEngine;
using VolkCharacters;
using VolkCharacters.Abilities;

namespace VolkArkanoid.Abilities
{
    [CreateAssetMenu(fileName = "MoreHeals", menuName = "Volk/Arkanoid/MoreHealsAbility", order = 1)]
    public class MoreHeals :AAbility
    {
        [field:SerializeField] public int AdditionalHealsCount { get; private set; }
        public override string Name => "More Heals";
        public override UsePlace UsePlace=> UsePlace.Spawn;

        public override void Use(ICharacter character)
        {
            var block = character as Block;
            block.AddHealth(AdditionalHealsCount);
        }
    }
}