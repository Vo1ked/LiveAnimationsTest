﻿using UnityEngine;
using VolkArkanoid.Signals;
using VolkCharacters;
using VolkCharacters.Abilities;
using Zenject;

namespace VolkArkanoid.Abilities
{
    public class StartMagnet : AAbility
    {
        public override string Name => "StartMagnet";
        public override UsePlace UsePlace=>UsePlace.Spawn;
        
        [Inject] private Ball _ball;
        [Inject] private SignalBus _signalBus;
        
        private int _useCount = 0;
        
        public override void Use(ICharacter abilityUser)
        {
            var platform = abilityUser as Platform;
            if (_useCount > 0 || platform == null)
                return;
            _useCount++;
            _ball.StopMove();
            _ball.transform.SetParent(platform.transform);
            _signalBus.Subscribe<PlatformReleasedSignal>(OnPlatformReleased);
        }

        private void OnPlatformReleased()
        {
            _ball.transform.SetParent(null);
            _ball.Direction = Vector2.up;
            _ball.StartMove();
            _signalBus.TryUnsubscribe<PlatformReleasedSignal>(OnPlatformReleased);
        }
    }
}