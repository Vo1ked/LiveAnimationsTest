﻿using System;
using VolkArkanoid.Save;

namespace VolkArkanoid.Save
{
    [Serializable]
    public class LevelData
    {
        public int Level;
        public BlockData[] Blocks;
    }
}