﻿using System;
using System.Linq;
using UnityEngine;
using VolkArkanoid.Abilities;
using VolkCharacters.Abilities;

namespace VolkArkanoid.Save
{
    [Serializable]
    public struct BlockData
    {
        public BlockData(Vector2 startPosition,bool destroyable,int blockId,AAbility[] abilities)
        {
            StartPosition = startPosition;
            Destroyable = destroyable;
            Abilities = abilities;
            BlockId = blockId;
        }
        
        [field: SerializeField] public Vector2 StartPosition {get; private set; }
        [field: SerializeField] public int BlockId {get; private set; }
        [field: SerializeField] public bool Destroyable {get; private set; }
        [field:SerializeField] public AAbility[] Abilities { get; private set; }
    }
}