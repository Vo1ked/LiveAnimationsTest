﻿using UnityEngine;
using VolkCharacters;

namespace VolkArkanoid
{
    [CreateAssetMenu(fileName = "ArkanoidCharacter", menuName = "Volk/Arkanoid/Character", order = 0)]
    public class ArkanoidPlayer : ACharacterData
    {
        [field: SerializeField] public int StartHealth { get; private set; } = 1;
        [field: SerializeField] public float StartPlatformSize { get; private set; } = 2;
        [field: SerializeField] public float MaxPlatformSize { get; private set; } = 10;
        [field: SerializeField] public float StartBallSpeed { get; private set; } = 15;
        [field: SerializeField] public Color PlatformColor { get; private set; } = Color.white;
    }
}