﻿using System;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace VolkArkanoid
{
    [RequireComponent(typeof(Rigidbody2D))]
    public class Ball : MonoBehaviour
    {
        [field: SerializeField] public Rigidbody2D Rigidbody { get; private set; }
        public Vector2 Normal { get; private set; }
        public int Damage { get; private set; } = 1;
        public float Speed = 5f;
        public Vector2 Direction = Vector2.up;

        private CancellationTokenSource _moveTokenSource;

        public void Reflect()
        {
            Vector2 reflectedVelocity = Vector2.Reflect(Rigidbody.linearVelocity, Normal);
            Direction = reflectedVelocity.normalized;
        }

        public void StartMove()
        {
            _moveTokenSource?.Cancel();
            _moveTokenSource = new CancellationTokenSource();
            _ = MoveAsync(_moveTokenSource.Token);
        }

        public void StopMove()
        {
            _moveTokenSource?.Cancel();
            Rigidbody.linearVelocity = Vector2.zero;
        }

        private async Task MoveAsync(CancellationToken token)
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    Rigidbody.linearVelocity = Direction * Speed;
                    await Awaitable.FixedUpdateAsync(token);
                }
            }
            catch (OperationCanceledException) { }
        }

        private void Awake()
        {
            Rigidbody = GetComponent<Rigidbody2D>();
        }

        private void OnCollisionEnter2D(Collision2D other)
        {
            Normal = other.contacts[0].normal;
            var hit = other.gameObject.GetComponent<IHittable>();
            hit?.Hit(this);
        }
    }
}