﻿namespace VolkArkanoid.Signals
{
    public struct BlockDestroyedSignal
    {
        public readonly int BlockId;

        public BlockDestroyedSignal(int blockId)
        {
            BlockId = blockId;
        }
    }

    public struct LoadLevelSignal
    {
        public readonly int Level;

        public LoadLevelSignal(int level)
        {
            Level = level;
        }
    }
    public struct PlatformReleasedSignal { }
    
    public struct FloorRichSignal { }
    
    public struct GameLoseSignal { }
    
    public struct GameWinSignal { }
}